import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <nav
      className="bg-white shadow-md flex justify-between items-center px-6 w-[1516px] h-[100px] -mt-[10px]"
    >
      {/* Logo / App Name */}
      <h1 className="text-2xl font-bold text-blue-600">MyApp</h1>

      {/* Links */}
      <div className="space-x-8 text-lg">
        <a href="/" className="text-gray-700 hover:text-blue-600">Home</a>
        <a href="/about" className="text-gray-700 hover:text-blue-600">About</a>
        <a href="/signup" className="text-gray-700 hover:text-blue-600">Signup</a>
        <a href="/login" className="text-gray-700 hover:text-blue-600">Login</a>
      </div>
    </nav>
  );
}