import Navbar from "../components/Navbar";
// import Footer from "../components/Footer";
import { useState } from "react";

export default function Signup() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    terms: false,
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Add your validation and API call here
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#faf7f7]">
      <Navbar />
      <main className="flex flex-1 items-center justify-center px-4 py-8">
        <div className="flex flex-col md:flex-row w-full max-w-4xl bg-white rounded-2xl shadow-lg overflow-hidden">
          {/* Left: Signup Form */}
          <div className="flex-1 flex flex-col justify-center px-8 py-10 relative bg-white">
            <h2 className="text-2xl md:text-2xl font-bold mb-6 text-black">
              Set up Your Cerope Account
            </h2>
            <form className="space-y-4" onSubmit={handleSubmit}>
              <input
                type="text"
                name="name"
                placeholder="Name"
                value={form.name}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-transparent focus:outline-none focus:ring-2 focus:ring-black"
                required
              />
              <input
                type="email"
                name="email"
                placeholder="Email Address"
                value={form.email}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-transparent focus:outline-none focus:ring-2 focus:ring-black"
                required
              />
              <input
                type="password"
                name="password"
                placeholder="Password"
                value={form.password}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-transparent focus:outline-none focus:ring-2 focus:ring-black"
                required
              />
              <input
                type="password"
                name="confirmPassword"
                placeholder="Confirm Password"
                value={form.confirmPassword}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-transparent focus:outline-none focus:ring-2 focus:ring-black"
                required
              />
              <div className="flex items-center">
                <input
                  type="checkbox"
                  name="terms"
                  id="terms"
                  checked={form.terms}
                  onChange={handleChange}
                  className="mr-2"
                  required
                />
                <label htmlFor="terms" className="text-xs text-gray-700">
                  I agree to Cerope's Terms of Service & Privacy Policy.
                </label>
              </div>
              <button
                type="submit"
                className="w-full bg-black text-white py-2 rounded-full font-semibold hover:bg-gray-900 transition"
              >
                Sign Up
              </button>
            </form>
            <p className="text-center text-sm text-gray-700 mt-4">
              Already a member?{" "}
              <a href="/login" className="text-blue-600 hover:underline">
                Sign in
              </a>
            </p>
            {/* Optional: faded background image */}
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-center bg-no-repeat bg-contain" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=facearea&w=600&q=80')" }} />
          </div>
          {/* Right: Illustration */}
          <div className="hidden md:flex flex-1 items-center justify-center bg-gradient-to-br from-[#f7e8ff] to-[#e0e7ff]">
            <div className="flex flex-col items-center">
              <img
                src="https://cdn.midjourney.com/2e2e2e2e2e2e2e2e2e2e2e2e2e2e2e2e/0_2.png"
                alt="Cerope Fashion"
                className="w-80 h-80 object-cover rounded-xl shadow-lg border-4 border-white"
              />
              <img
                src="/vite.svg"
                alt="Cerope Logo"
                className="w-16 mt-4"
              />
            </div>
          </div>
        </div>
      </main>
      {/* <Footer /> */}
    </div>
  );
}